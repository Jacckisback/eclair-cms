<?php
 defined('ECLAIR') || exit; echo $v['inner']; 