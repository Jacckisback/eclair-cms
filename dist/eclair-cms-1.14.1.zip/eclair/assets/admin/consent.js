(()=>{
const allow=document.querySelector('[data-gate]');
if(!allow||!allow.form)return;
const DELAY=800;
const now=()=>performance.now();
let since=null;
let opened=null;
let opener=null;
let down=null;
const lock=()=>{since=null;opened=null;opener=null;allow.disabled=true;};
const watch=()=>{
if(document.visibilityState!=='visible'||!document.hasFocus())lock();
else if(since===null)since=now();
};
const gesture=(e)=>{
if(e.type==='pointerdown')down=now();
watch();
if(since!==null&&opened===null&&now()-since>=DELAY){
opened=now();
opener=e;
allow.disabled=false;
}
};
document.addEventListener('visibilitychange',watch);
window.addEventListener('focus',watch);
window.addEventListener('blur',lock);
window.addEventListener('pagehide',lock);
window.addEventListener('pageshow',()=>{lock();watch();});
['pointermove','pointerdown','mousemove','touchstart','wheel','keydown','focusin'].forEach((type)=>window.addEventListener(type,gesture,{capture:true,passive:true}));
allow.addEventListener('click',(e)=>{
if(e.detail>0&&(down===null||opened===null||down<=opened)){
e.preventDefault();
e.stopImmediatePropagation();
}
});
allow.form.addEventListener('keydown',(e)=>{
if(e.key!=='Enter'||e.isComposing||!e.target.matches('input'))return;
e.preventDefault();
if(!allow.disabled&&opener!==e)allow.click();
});
lock();
watch();
})();
