<?php
 declare(strict_types=1); namespace Eclair; defined('ECLAIR') || exit; final class StorageException extends \RuntimeException { } 